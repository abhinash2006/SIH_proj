# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# Custom UAV / Aerial Disaster Dataset Loader for VGGT Fine-Tuning.

import json
import os
import os.path as osp
import logging
import random
import cv2
import numpy as np

from data.dataset_util import *
from data.base_dataset import BaseDataset

logger = logging.getLogger(__name__)


class UAVDataset(BaseDataset):
    """
    Dataset loader for calibrated UAV multi-view sequences.
    Strictly adheres to VGGT BaseDataset interface.
    Enforces the 3-tier supervision taxonomy:
      - GROUND_TRUTH (RTK / LiDAR)
      - PSEUDO_GROUND_TRUTH (Validated COLMAP SfM+MVS)
      - MODEL_PREDICTION (Strictly REJECTED from training)
    """

    def __init__(
        self,
        common_conf,
        split: str = "train",
        DATA_DIR: str = None,
        MANIFEST_PATH: str = None,
        min_num_images: int = 4,
        len_train: int = 1000,
        len_test: int = 100,
    ):
        super().__init__(common_conf=common_conf)

        self.debug = common_conf.debug
        self.training = common_conf.training
        self.get_nearby = common_conf.get_nearby
        self.load_depth = common_conf.load_depth
        self.inside_random = common_conf.inside_random
        self.allow_duplicate_img = common_conf.allow_duplicate_img

        if DATA_DIR is None:
            raise ValueError("DATA_DIR must be specified for UAVDataset.")
        if MANIFEST_PATH is None:
            manifest_file = f"{split}.json"
            MANIFEST_PATH = osp.join(DATA_DIR, manifest_file)

        self.DATA_DIR = DATA_DIR
        self.MANIFEST_PATH = MANIFEST_PATH
        self.min_num_images = min_num_images

        if split in ["train", "val"]:
            self.len_train = len_train
        elif split in ["test"]:
            self.len_train = len_test
        else:
            self.len_train = len_train

        logger.info(f"Loading UAVDataset from manifest: {self.MANIFEST_PATH}")
        if not osp.exists(self.MANIFEST_PATH):
            raise FileNotFoundError(f"Manifest file not found: {self.MANIFEST_PATH}")

        with open(self.MANIFEST_PATH, "r") as f:
            raw_manifest = json.load(f)

        self.data_store = {}
        total_frames = 0

        for seq_name, seq_content in raw_manifest.items():
            if isinstance(seq_content, dict):
                supervision = seq_content.get("supervision_type", "UNKNOWN")
                if supervision == "MODEL_PREDICTION":
                    raise ValueError(
                        f"CRITICAL ERROR: Sequence '{seq_name}' is tagged as 'MODEL_PREDICTION'. "
                        "VGGT predictions are STRICTLY FORBIDDEN as training supervision."
                    )
                frames = seq_content.get("frames", [])
            elif isinstance(seq_content, list):
                frames = seq_content
            else:
                continue

            if len(frames) < min_num_images:
                logger.warning(
                    f"Sequence {seq_name} has only {len(frames)} frames (< min {min_num_images}). Skipping."
                )
                continue

            self.data_store[seq_name] = frames
            total_frames += len(frames)

        self.sequence_list = list(self.data_store.keys())
        self.sequence_list_len = len(self.sequence_list)
        self.total_frame_num = total_frames

        if self.sequence_list_len == 0:
            raise ValueError(f"No valid sequences loaded from manifest: {self.MANIFEST_PATH}")

        status = "Training" if self.training else "Evaluation"
        logger.info(f"{status}: UAV Dataset sequences: {self.sequence_list_len}, total frames: {self.total_frame_num}")

    def get_data(
        self,
        seq_index: int = None,
        img_per_seq: int = None,
        seq_name: str = None,
        ids: list = None,
        aspect_ratio: float = 1.0,
    ) -> dict:
        """
        Retrieves a multi-view batch of frames for one sequence.
        Returns:
            dict containing images, depths, extrinsics, intrinsics,
            cam_points, world_points, point_masks, ids, seq_name.
        """
        if self.inside_random or seq_index is None:
            seq_index = random.randint(0, self.sequence_list_len - 1)

        if seq_name is None:
            seq_name = self.sequence_list[seq_index]

        metadata = self.data_store[seq_name]
        total_seq_len = len(metadata)

        if img_per_seq is None or img_per_seq <= 0:
            img_per_seq = min(total_seq_len, 4)

        if ids is None:
            if total_seq_len >= img_per_seq and not self.allow_duplicate_img:
                # Sample contiguous window or uniform strides for temporal coherence
                start_idx = random.randint(0, total_seq_len - img_per_seq)
                ids = np.arange(start_idx, start_idx + img_per_seq)
            else:
                ids = np.random.choice(total_seq_len, img_per_seq, replace=self.allow_duplicate_img)

        annos = [metadata[int(i)] for i in ids]
        target_image_shape = self.get_target_shape(aspect_ratio)

        images = []
        depths = []
        cam_points = []
        world_points = []
        point_masks = []
        extrinsics = []
        intrinsics = []
        image_paths = []
        original_sizes = []

        for anno in annos:
            filepath = anno["filepath"]
            image_path = osp.join(self.DATA_DIR, filepath)
            image = read_image_cv2(image_path)
            if image is None:
                raise FileNotFoundError(f"Image not found at {image_path}")

            original_size = np.array(image.shape[:2])

            if self.load_depth:
                depth_rel_path = anno.get("depth_path")
                depth_path = osp.join(self.DATA_DIR, depth_rel_path) if depth_rel_path else None
                depth_scale = float(anno.get("depth_scale", 1000.0))

                if depth_path and osp.exists(depth_path):
                    # Read 16-bit uint16 millimeter depth or float32 depth
                    depth_raw = cv2.imread(depth_path, cv2.IMREAD_UNCHANGED)
                    if depth_raw is not None:
                        depth_map = depth_raw.astype(np.float32) / depth_scale
                    else:
                        depth_map = np.zeros(original_size, dtype=np.float32)
                else:
                    depth_map = np.zeros(original_size, dtype=np.float32)

                mask_rel_path = anno.get("mask_path")
                if mask_rel_path:
                    mask_path = osp.join(self.DATA_DIR, mask_rel_path)
                    if osp.exists(mask_path):
                        mvs_mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) > 128
                        depth_map[~mvs_mask] = 0.0

                depth_map = threshold_depth_map(depth_map, min_percentile=-1, max_percentile=98)
            else:
                depth_map = None

            extri_opencv = np.array(anno["extri"], dtype=np.float32)
            intri_opencv = np.array(anno["intri"], dtype=np.float32)

            (
                image,
                depth_map,
                extri_opencv,
                intri_opencv,
                world_coords_points,
                cam_coords_points,
                point_mask,
                _,
            ) = self.process_one_image(
                image,
                depth_map,
                extri_opencv,
                intri_opencv,
                original_size,
                target_image_shape,
                filepath=filepath,
            )

            images.append(image)
            depths.append(depth_map)
            extrinsics.append(extri_opencv)
            intrinsics.append(intri_opencv)
            cam_points.append(cam_coords_points)
            world_points.append(world_coords_points)
            point_masks.append(point_mask)
            image_paths.append(image_path)
            original_sizes.append(original_size)

        batch = {
            "seq_name": seq_name,
            "ids": np.array(ids, dtype=np.int64),
            "frame_num": len(extrinsics),
            "images": images,
            "depths": depths,
            "extrinsics": extrinsics,
            "intrinsics": intrinsics,
            "cam_points": cam_points,
            "world_points": world_points,
            "point_masks": point_masks,
            "original_sizes": original_sizes,
            "tracks": None,
            "track_masks": None,
        }
        return batch
